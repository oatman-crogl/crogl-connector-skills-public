# Tines — Deep Reference

Loaded on demand when SKILL.md isn't enough. Full response-field reference, less-common endpoints, and worked end-to-end examples.

## Story object — full field reference

A `GET /api/v1/stories` page returns `{stories: [...], meta: {...}}`. Each story object has these fields (per Tines API v1 as of 2026-06):

| Field | Type | Notes |
|-------|------|-------|
| `id` | int | Stable across renames. Use this for `?story_id=<id>` queries. |
| `name` | string | Human-readable; can be renamed in the UI without breaking IDs. |
| `description` | string | Free-form. Often empty in less-mature tenants; some teams use it for the inputs schema in plain text. |
| `tag_list` | string[] | Server-side filterable via `?tags=<csv>`. Stories without tags can't be filtered server-side. |
| `team_id` | int | Tines tenants are partitioned by team. `?team_id=<id>` filters server-side. |
| `entry_agent_ids` | int[] | Agents that can serve as story entry points. Empty array means no Send-to-Story support — webhook only. |
| `send_to_story_enabled` | bool (optional) | Explicit flag when present. Don't trust its absence as "not supported" — fall back to `entry_agent_ids` non-empty. |
| `disabled` | bool | If true, the story will accept events but agents are paused. Discovery should skip these or flag them. |
| `mode` | string | `LIVE` / `TEST` / `STAGING`. Production stories are `LIVE`. |
| `published` | bool | Whether the story is shared as a template. Not a runtime flag — ignore for catalog purposes. |
| `created_at` / `updated_at` | ISO timestamp | UTC. Useful for "what's new since last discovery". |

### `meta` object on the list response

| Field | Notes |
|-------|-------|
| `current_page` | 1-indexed |
| `per_page` | Default 20, max 200. Raise via `?per_page=N`. |
| `pages` | Total pages — multiply by `per_page` for a rough total. |
| `count` | Exact total count of stories matching the filter. |

## Agent object — full field reference

`GET /api/v1/agents?story_id=<id>` returns `{agents: [...]}`. Common `type` values:

| Type | Role | Why we care |
|------|------|-------------|
| `Agents::WebhookAgent` | External trigger | The discovery target — `options.path` + `options.secret` build the webhook URL. |
| `Agents::EventTransformationAgent` | Re-shape events | Sometimes the de-facto entry agent when stories use Send-to-Story without an explicit webhook. |
| `Agents::HTTPRequestAgent` | Outbound HTTP | Common in approval-pair stories — Story A's last HTTPRequestAgent posts the Slack approval card. |
| `Agents::EmailAgent` / `Agents::SlackAgent` | Notification | Frequent in approval flows; not entry points. |
| `Agents::TriggerAgent` | Conditional branching | Internal control flow. Not entry points. |
| `Agents::SendToStoryAgent` | Cross-story dispatch | When present, the source story can chain into another via the API rather than a webhook. |

### WebhookAgent `options` shape

```json
{
  "id": <agent_id>,
  "name": "Webhook",
  "type": "Agents::WebhookAgent",
  "story_id": <story_id>,
  "options": {
    "path": "<webhook_path>",
    "secret": "<webhook_secret>",
    "expected_receive_period_in_days": 365,
    "payload_type": "json",
    "verbs": "post"
  }
}
```

`path` and `secret` are the two halves. Tenant-level webhook URL: `https://<tenant>.tines.com/webhook/<path>/<secret>`.

Some webhook agents have an `options.schema` field with an explicit JSON Schema for the expected inputs — when present, use it for client-side validation. When absent, fall back to `{type: "object", additionalProperties: true}` and rely on Tines' own input validation (which surfaces in 422 responses).

## Discovery — worked end-to-end example

User asks: *"What remediation stories do we have available?"*

### 1. List stories tagged `remediation`

```
GET /api/v1/stories?tags=remediation&per_page=50
```

Sample response:

```json
{
  "stories": [
    {
      "id": <story_id_1>,
      "name": "Block IP at Firewall",
      "tag_list": ["remediation"],
      "entry_agent_ids": [<entry_id_1>],
      "send_to_story_enabled": true
    },
    {
      "id": <story_id_2>,
      "name": "Isolate Host Request",
      "tag_list": ["remediation"],
      "entry_agent_ids": [<entry_id_2>]
    },
    {
      "id": <story_id_3>,
      "name": "Isolate Host Execute",
      "tag_list": ["remediation"]
    },
    {
      "id": <story_id_4>,
      "name": "SOC Slack Alert",
      "tag_list": ["remediation", "alerting"],
      "entry_agent_ids": [<entry_id_4>]
    }
  ],
  "meta": {"current_page": 1, "per_page": 50, "pages": 1, "count": 4}
}
```

### 2. Detect the two-story approval pair

Name-pair detection: `Isolate Host Request` + `Isolate Host Execute` → treat `Execute` as internal; keep only `Request` in the user-facing catalog.

### 3. Enumerate trigger agents for each user-facing story

```
GET /api/v1/agents?story_id=<story_id_1>
GET /api/v1/agents?story_id=<story_id_2>
GET /api/v1/agents?story_id=<story_id_4>
```

Filter each response to `type == "Agents::WebhookAgent"`.

### 4. Build catalog

| Playbook | Story ID | Trigger type | Webhook path | Approval | Send-to-Story |
|----------|----------|--------------|--------------|----------|---------------|
| Block IP at Firewall | `<story_id_1>` | Webhook | `<webhook_path>/<secret-redacted>` | auto | yes |
| Isolate Host | `<story_id_2>` | Webhook | `<webhook_path>/<secret-redacted>` | manual (paired with `<story_id_3>`) | no |
| SOC Slack Alert | `<story_id_4>` | Webhook | `<webhook_path>/<secret-redacted>` | auto | yes |

Render that table to the user. Cache the unredacted webhook paths internally for the duration of the session.

## Execution — worked example with header capture

User has approved running `SOC Slack Alert` with `{summary: "<X>", severity: "<Y>", source_ip: "<Z>"}`.

### Prefer Send-to-Story (bearer-only path)

```
POST /api/v1/stories/<story_id_4>/events
Content-Type: application/json

{"summary": "<X>", "severity": "<Y>", "source_ip": "<Z>"}
```

Successful response:

```
HTTP/1.1 202 Accepted
X-Tines-Event-Id: <event_id>
X-Tines-Status: queued
Content-Type: application/json

{"message": "Event queued"}
```

Render: `status: success · http_status: 202 · X-Tines-Event-Id: <event_id> · X-Tines-Status: queued · body: "Event queued"`.

### Fall back to webhook if Send-to-Story 404s

```
POST /webhook/<webhook_path>/<webhook_secret>
Content-Type: application/json

{"summary": "<X>", "severity": "<Y>", "source_ip": "<Z>"}
```

Response is shaped identically — `X-Tines-Event-Id` header is still present.

### 504 handling

```
HTTP/1.1 504 Gateway Timeout
X-Tines-Event-Id: <event_id>
X-Tines-Status: processing
```

Treat as success, not error. Render: `status: timeout (async) · http_status: 504 · X-Tines-Event-Id: <event_id> · message: "Sync window exceeded; run continues asynchronously. Check Tines UI at https://<tenant>.tines.com/stories/<story_id>"`.

## Less-common read endpoints

| Method | Path | Use | Notes |
|--------|------|-----|-------|
| GET | `/api/v1/teams` | List teams | Useful for multi-team tenants to scope discovery via `?team_id=<id>`. |
| GET | `/api/v1/stories/<story_id>/runs` | List run history | Paginated. Doesn't include full event payloads — just IDs and status. |
| GET | `/api/v1/events/<event_id>` | Event detail | Use the `X-Tines-Event-Id` returned from a trigger call to drill into the actual run. |
| GET | `/api/v1/notes` | List notes attached to stories | Free-form annotations the author left; sometimes contains the inputs schema. |
| GET | `/api/v1/stories/<story_id>/export` | Export story as JSON | Full agent graph + options. Large response — only call when the user explicitly needs to introspect the story logic. |

## Pagination handling

For any paginated endpoint, `?page=N&per_page=M`:

- `per_page` defaults to 20, max 200. Use 50 for discovery scans; use 200 only if you've confirmed the result set is bounded.
- Don't paginate exhaustively without user confirmation when `meta.count` exceeds 100 — render the first page and ask the user to filter.
- `Link:` response header has `next` / `prev` / `last` URLs in standard RFC 5988 format if you prefer to follow them rather than constructing `?page=N` manually.

## Rate limits

Tines enforces:

- Per-token: ~3,600 requests/hour (varies by plan; check your tenant's response headers)
- Per-tenant: aggregate cap above the per-token cap

Response headers on every call:

```
X-RateLimit-Limit: 3600
X-RateLimit-Remaining: 3582
X-RateLimit-Reset: <epoch_seconds>
```

When `X-RateLimit-Remaining < 10`, slow down. On 429, sleep until `X-RateLimit-Reset` and retry once; if 429 again, stop and surface to the user.

## Common failure modes (the long tail)

| Symptom | Cause | Fix |
|---------|-------|-----|
| `GET /api/v1/agents` returns 1000s of agents | Forgot `?story_id=` | Always include `?story_id=` |
| Webhook returns 200 but story doesn't run | `disabled: true` on the story | Re-enable in the Tines UI, or stop using the story |
| Send-to-Story 404 even though story has `entry_agent_ids` | Entry agent isn't a Send-to-Story-compatible type | Fall back to webhook |
| Webhook 200, response body is the request body echoed back | Story has no agents downstream of the webhook | Author error in Tines — surface to the user |
| `/api/v1/stories?tags=remediation` returns empty when stories ARE tagged | Tag name case mismatch (`remediation` vs `Remediation`) | Tines tag matching is case-sensitive; re-discover with the exact case |
| Authorization works for `/api/v1/stories` but 403 on `/api/v1/stories/<id>/events` | Token has read scope but not "send to story" | Generate a new token with the additional scope |
| Webhook URL the agent built returns 404 but discovery just succeeded | Webhook agent was rotated between discovery and execution | Re-discover and retry once |

## Two-story approval pattern — full detection logic

The bundled Crogl Tines plugin used a single `requires_approval: true` flag in operator-supplied config. Real Tines tenants almost never model approval that way — they use a two-story pattern. Detection:

### Necessary signal — name pair

A "Request" / "Propose" / "Approval" story exists AND a sibling "Execute" / "Apply" / "Do" / "Action" story exists with the same prefix.

### Sufficient signal — agent graph

The Request story's final agent is `Agents::HTTPRequestAgent` posting to a Slack `chat.postMessage` URL with an interactive `blocks` payload containing buttons; one button's `url` field points at the Execute story's webhook URL.

### Heuristic — tag pair

Some teams tag both halves with `requires-approval`; rare but check after name-pair.

When confident the pair exists, the user-facing catalog should:

- Include only the Request story (with a `requires_approval: true` annotation)
- Hide the Execute story
- Note in the rendering: "Approval gate handled by Tines — Slack approval message goes to `<channel>` (from Request story's HTTPRequestAgent payload)"

## When NOT to use Send-to-Story

Even when Send-to-Story is supported, prefer webhook in these cases:

- The story was explicitly authored as a public webhook receiver for an external system that includes Tines as one of many destinations — using the webhook URL preserves consistency with the external caller's pattern
- The customer's Tines tenant has bearer-token rate limits that are tighter than per-webhook limits — webhook calls are accounted differently in some tenants
- The story's entry agent does input transformation that's bypassed by Send-to-Story (rare; check by comparing the agent graph)

Default still: prefer Send-to-Story; fall back to webhook on 404/405.
