---
name: tines-reference
description: "PREFER THIS SKILL for ad-hoc / exploratory queries against a Tines SOAR tenant: 'list playbooks', 'show me stories tagged X', 'what stories are in this tenant', 'describe story <id>', 'show me the trigger for story <id>', 'find the webhook URL for story X', 'what fields does story X take', 'recent runs of story X'. Composes a GET against `/api/v1/stories` or `/api/v1/agents` against the registered Tines Custom Connector and renders the response as a scannable analyst table. Also covers the request shape for the two execution surfaces — Send-to-Story (`POST /api/v1/stories/:id/events`) and webhook (`POST /webhook/<path>/<secret>`) — but those are gated as WRITE actions: never invoke without explicit user approval naming the target story and inputs. Do NOT use for end-to-end remediation orchestration (intent-routing, approval gates, calling-contract for sibling skills) — that's a workflow skill layered on top. Tines SOAR ONLY — for other SOAR products (XSOAR, Swimlane, Splunk SOAR) use the relevant reference."
version: "0.1.0"
---

# Tines — Reference / Ad-hoc Query Cookbook

> **v0.1.0 (2026-06-02) — Initial release.** Seeded from live-validated discovery against a Tines tenant using the bearer-authed Custom Connector approach (Strategy B from the bundled-plugin replacement evaluation: single connector at `https://<tenant>.tines.com` with an `Authorization: Bearer {{secret}}` header). Covers the four read endpoints used to build a playbook catalog (`/api/v1/stories`, `/api/v1/agents`), the two write endpoints used to trigger a story (`/api/v1/stories/:id/events`, `/webhook/<path>/<secret>`), and the discovery + execution patterns that match the bundled Tines plugin's behavior without requiring the plugin itself. The orchestration / approval-gate / intent-routing layer is intentionally out of scope here — it belongs in a workflow skill on top.

Cookbook style: no phase gates, no STOP gates, no orchestration. Read the catalog, build the call, render the result, stop. For end-to-end remediation flows (intent → playbook lookup → approval gate → execution → caller narration), use a Tines workflow skill layered on top of this reference.

## Connector selection (run once at start)

1. Walk the available `mcp__crogld__*` MCP tools to find connector tools.
2. Pick the connector tool whose name contains `tines`, `tines-soar`, or `tines_soar`. Single-vendor — there is no Tines-cloud vs Tines-on-prem split to disambiguate.
3. If none matches, list the available connectors and tell the user "no Tines connector is registered on this install — register one with `base_url=https://<tenant>.tines.com` and an `Authorization: Bearer {{secret}}` header before retrying." Do NOT attempt to construct webhook URLs against a tenant root that isn't registered.
4. Cache the connector tool name. Invoke it with `{ method, path, query?, body?, headers? }`.

Match on vendor substring rather than tool-name prefix — the `api_proxy_` prefix is an implementation detail and is mid-rebrand to `connector_` across Crogl releases.

## Auth recap

- Single header: `Authorization: Bearer <api_token>` (injected by the connector — never construct or prompt the user for the token)
- API token is generated in Tines under **Settings → API Tokens → New Token**. Read scope is sufficient for discovery; Send-to-Story execution needs the additional "send to story" permission
- Webhook execution paths (`/webhook/<path>/<secret>`) don't use the bearer token — the secret in the URL path IS the auth. The connector still injects the bearer header on those calls; Tines ignores it (harmless)
- 401 on a `/api/v1/*` call → token invalid, expired, or lacks scope. Surface the error and stop; do not retry

## Tool call shape (critical)

The connector tool splits URL into separate fields. **Never embed `?…` in `path`** — crogld URL-encodes the `path` value, so a `?` becomes `%3F` and Tines returns 404.

```json
{"method": "GET", "path": "/api/v1/agents", "query": {"story_id": "<story_id>"}}
```

For execution endpoints with a JSON body:

```json
{"method": "POST", "path": "/api/v1/stories/<story_id>/events", "body": "{\"hostname\":\"<X>\",\"reason\":\"<Y>\"}", "headers": {"Content-Type": "application/json"}}
```

The `body` field is a JSON-encoded string, not a nested object — the connector forwards it verbatim.

## Context budget rules

1. **Stories list is paginated.** `/api/v1/stories` returns 20 per page by default. Enterprise tenants can have 100s of stories. Always pull page 1 first and read `meta.pages` / `meta.count` before deciding whether to enumerate further. Don't iterate every page unless the user explicitly asked for an exhaustive list.
2. **Filter server-side via `?tags=<csv>` or `?team_id=<id>` when the user named a tag or team.** Stops hundreds of irrelevant stories from blowing the context budget. Tag filter is exact match on a single tag; pass multiple via `?tags[]=<a>&tags[]=<b>`.
3. **Agents enumeration is per-story, all-types.** `/api/v1/agents?story_id=:id` returns every agent in the story (webhook, email, HTTP, transform, etc.) — a complex story can have 50+. Filter to `type == "Agents::WebhookAgent"` (or whichever trigger type you need) on the client side; don't render the full agent dump.
4. **Default render: ≤25 stories or ≤10 agents inline.** Beyond that, truncate with a count and offer to filter. The full agent payload per row is large (300–1500 bytes); 50 agents inline blows context.
5. **Hard cap: if any tool result exceeds 30 KB, STOP** and re-issue with tighter scope (a `?tags=` filter, a smaller page size, etc.).
6. **Don't re-discover within a session.** Discovery results are stable for the conversation — cache the catalog in your reasoning context and reuse it across follow-up queries.

## Endpoint catalog

### Read — discovery + introspection

| Method | Path | Use |
|--------|------|-----|
| GET | `/api/v1/stories` | List stories. Paginated (`per_page` default 20). Server-side filters: `?tags=<csv>`, `?team_id=<id>`, `?search=<text>`. |
| GET | `/api/v1/stories/<story_id>` | Story detail. Includes `tag_list`, `description`, `entry_agent_ids`, `send_to_story_enabled` (when present). |
| GET | `/api/v1/agents` | List agents. **Always pass `?story_id=<id>`** — without it, returns every agent in the tenant. |
| GET | `/api/v1/agents/<agent_id>` | Agent detail. For `Agents::WebhookAgent`, `options.path` and `options.secret` are the two halves needed to build the webhook URL. |

### Write — execution (gate on explicit user approval)

| Method | Path | Body | Use |
|--------|------|------|-----|
| POST | `/api/v1/stories/<story_id>/events` | Inputs as JSON object | **Send-to-Story.** Bearer-authed. Only works when the story's entry agent supports it (presence of `entry_agent_ids` or `send_to_story_enabled: true` is the strongest signal). Preferred over webhook because the secret stays in the proxy header. |
| POST | `/webhook/<webhook_path>/<webhook_secret>` | Inputs as JSON object | **Webhook trigger.** Universal — every webhook-triggered story supports this. Secret travels in the URL path; this is the canonical Tines webhook auth model, not a leak per se, but it does mean the secret crosses chat context when the agent constructs the path. |

**Never invoke a write endpoint without explicit user approval that names the target story (by name, not just ID) and confirms the inputs.** Discovery is safe; execution is not.

### Endpoints NOT to call (common LLM defaults that 404)

- `/api/v1/playbooks` — Tines doesn't use the word "playbook" in its data model; stories are the unit. The bundled Crogl plugin called them "playbooks" as a SOC-friendly rename, but the API uses "stories".
- `/api/v2/*` — Tines is on `v1` only as of 2026; `v2` paths 404 across the board.
- `/api/v1/runs` (no story_id) — runs aren't a top-level resource; query event history per-story via the events endpoint or the UI.

## Discovery pattern (build a playbook catalog from scratch)

This is the standard 3-step pattern. Run it once per session and cache the result.

### Step 1 — List candidate stories

If the user named a tag or team, filter server-side:

```
GET /api/v1/stories?tags=remediation&per_page=50
```

Otherwise pull page 1 and inspect `meta.count`:

```
GET /api/v1/stories?per_page=20
```

Render: `id · name · description (truncate to 60 chars) · tag_list`. If `meta.count > 50`, prompt the user to narrow rather than enumerating all pages.

### Step 2 — Enumerate trigger agents per story

For each story the user wants in the catalog:

```
GET /api/v1/agents?story_id=<story_id>
```

Filter the response to `agents[].type == "Agents::WebhookAgent"`. Most stories have exactly one webhook trigger; if there are multiple, the one named "Webhook" or matching the story name is typically the public entry point. If zero webhook agents exist, the story is internal (called by another story) — exclude it from the user-facing catalog.

### Step 3 — Extract webhook details and assemble catalog entry

For each webhook agent:

```
agent.options.path     →  webhook path component
agent.options.secret   →  webhook secret component
```

Combined webhook URL: `https://<tenant>.tines.com/webhook/<path>/<secret>` (the connector already knows `<tenant>` — the agent constructs only the trailing `/webhook/<path>/<secret>`).

### Two-story approval pattern (detect, don't fabricate)

Tines models manual approval as **two stories**, not a single story with a tag:

- **Story A — "<Action> Request"** — webhook-triggered, posts a Slack approval prompt
- **Story B — "<Action> Execute"** — webhook-triggered, performs the actual action; called by Story A's Slack approval action when the analyst clicks Approve

Detection heuristics (in order of reliability):

1. **Name pair match** — Story A name contains "Request" / "Propose" / "Approval"; Story B name is the same prefix with "Execute" / "Apply" / "Do" / "Action" suffix
2. **Tag match** — Story A tagged `requires-approval`, `manual-approval`, or `approval-gate`
3. **Agent-graph match** — Story A's last agent is a Slack `Agents::HTTPRequestAgent` posting an interactive message; Story B is referenced from that message's button URL

When you detect the pair, treat Story A as the user-facing entry and Story B as internal — exclude Story B from the catalog. The bundled Crogl plugin's tag-based `requires_approval` detection misses this; name-pair detection is more reliable in real tenants.

## Query recipes

| User intent | Call |
|-------------|------|
| List all stories | `GET /api/v1/stories?per_page=20` (then `meta.pages` for scope) |
| List stories tagged `<tag>` | `GET /api/v1/stories?tags=<tag>&per_page=50` |
| Show story `<id>` | `GET /api/v1/stories/<id>` |
| List trigger agents for story `<id>` | `GET /api/v1/agents?story_id=<id>` → filter `type=="Agents::WebhookAgent"` |
| Get webhook URL for story `<id>` | Step 2 + Step 3 of discovery: enumerate agents → pick webhook → `options.path` + `options.secret` |
| What inputs does story `<id>` take | `GET /api/v1/agents/<entry_agent_id>` → look at `options.schema` if present; otherwise check the story description, or treat as `{type: "object", additionalProperties: true}` and ask the user |
| Find the executor half of an approval pair | Apply the two-story name-pair detection above to a `?tags=remediation` story list |
| Trigger story `<id>` via Send-to-Story (write — needs approval) | `POST /api/v1/stories/<id>/events` body `<inputs JSON>` |
| Trigger story via webhook (write — needs approval) | `POST /webhook/<path>/<secret>` body `<inputs JSON>` |

## Send-to-Story vs Webhook (which to prefer)

| Aspect | Send-to-Story | Webhook |
|--------|---------------|---------|
| Auth | Bearer header (injected by connector) | Path-embedded secret |
| Secret hygiene | Secret stays in proxy header; never in chat context | Secret crosses chat context when agent builds the path |
| Availability | Only when story has it enabled (look for `entry_agent_ids` or `send_to_story_enabled: true`) | Universal — every webhook-triggered story |
| Response shape | Same — JSON body, `X-Tines-Event-Id` / `X-Tines-Status` headers, 200/201/202 success, 504 async-timeout | Same |

**Preference:** attempt Send-to-Story first when a story signals support for it; fall back to webhook on 404/405. When both work, the bearer-only path is cleaner.

## Rendering pattern

Scannable tables, default columns:

- **Story list:** id · name · description (truncate at 60) · tag_list (csv) · entry_agent_count
- **Agent list (filtered to webhook triggers):** id · name · type · options.path (mask the secret: `<path>/<secret-redacted>`)
- **Execution result:** status · http_status · X-Tines-Event-Id · X-Tines-Status · response body (truncate at 200 chars)

≤25 stories or ≤10 agents → inline. Beyond → show first N + `"(M more, ask to filter)"`. Render once, then drop the raw response from your reasoning context.

**Never render the webhook secret in plain user-facing output.** Mask as `<secret-redacted>` even if the user asked for the URL — if they specifically need it, return it once in a code block with a "treat as sensitive" note.

## Error handling

- **401** — bearer token invalid, expired, or lacks scope. Stop; tell the analyst to rotate the token at `https://<tenant>.tines.com/users/api_tokens`. Do not retry.
- **404 on `/api/v1/stories`** — connector `base_url` is wrong (typo in tenant subdomain) or token has zero read access. Stop; ask the operator to verify the connector config.
- **404 on `/api/v1/stories/<id>/events`** — Send-to-Story not enabled on this story. Fall back to webhook execution if the user already approved.
- **404 on `/webhook/<path>/<secret>`** — webhook path or secret wrong; either the discovery data is stale or the story's webhook agent was rotated. Re-discover from `/api/v1/agents` and retry once.
- **422 on Send-to-Story or webhook** — input payload doesn't match the story's expected fields. Surface the body verbatim; the Tines response includes which fields are missing.
- **429** — tenant rate limit (Tines enforces per-token + per-tenant). Back off and re-discover with a smaller page size; do NOT loop-retry without backoff.
- **504 on execution** — sync window exceeded; the story is running asynchronously. Treat as success, return the `X-Tines-Event-Id`, and tell the analyst to check the Tines UI for completion.
- **TLS handshake error** — only happens on self-hosted Tines with a private CA; the connector needs the customer CA injected. Surface and stop; this is install-time configuration, not a query problem.

## Guardrails

- **Discovery is read-only and safe by default.** All `GET /api/v1/*` calls can run without user approval.
- **Execution requires explicit user approval naming the target story by name (not just ID) and the inputs.** "Run story 12345" is not enough; "Run the 'Block IP at firewall' story with `ip=203.0.113.42`" is.
- **Never invoke a story not in the discovered catalog.** No story IDs from chat history, no IDs guessed from naming convention. If it's not in the catalog the user can see, it doesn't exist.
- **Webhook secrets surface in `/api/v1/agents/<id>` responses.** Treat the entire agent-detail blob as sensitive; cache in agent memory, never echo back to the user unless they specifically ask for the webhook URL.
- **Never construct a webhook URL the agent didn't discover.** No "guess the path from the story name" — the path/secret pair must come from a live `/api/v1/agents` response.
- **No silent fallback past 401.** Surface auth failures; don't retry with the same token.

## What this skill is NOT for

- **Intent → playbook routing for sibling skills** — that's an orchestration / workflow skill (Intent Map, calling contract, approval gate as a returned status). Layer it on top of this reference.
- **Per-customer playbook catalogs** — those are install-specific and belong with the customer's deployment artifacts, not in a shared reference.
- **Story authoring / editing** — Tines stories are authored in the Tines UI; the API is read + trigger only for our purposes.
- **Tines admin operations** (team management, user provisioning, billing) — out of scope.
